<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Quản lý Sản phẩm</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .form-container { width: 400px; padding: 20px; border: 1px solid #ddd; border-radius: 5px; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; }
        .form-group input { width: 100%; padding: 8px; box-sizing: border-box; }
        .btn-submit { background-color: #007bff; color: white; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; }
        .btn-cancel { background-color: #6c757d; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; display: inline-block; margin-left: 10px; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>
            <c:if test="${product != null}">Sửa thông tin sản phẩm</c:if>
            <c:if test="${product == null}">Thêm sản phẩm mới</c:if>
        </h2>
        
        <c:if test="${product != null}">
            <form action="update" method="post">
        </c:if>
        <c:if test="${product == null}">
            <form action="insert" method="post">
        </c:if>
        
            <c:if test="${product != null}">
                <input type="hidden" name="id" value="<c:out value='${product.id}' />" />
            </c:if>
            
            <div class="form-group">
                <label>Tên sản phẩm:</label>
                <input type="text" name="name" value="<c:out value='${product.name}' />" required />
            </div>
            
            <div class="form-group">
                <label>Giá:</label>
                <input type="number" step="0.01" name="price" value="<c:out value='${product.price}' />" required />
            </div>
            
            <div class="form-group">
                <label>Số lượng:</label>
                <input type="number" name="quantity" value="<c:out value='${product.quantity}' />" required />
            </div>
            
            <button type="submit" class="btn-submit">Lưu</button>
            <a href="list" class="btn-cancel">Hủy</a>
        </form>
    </div>
</body>
</html>

