<% response.sendRedirect("list"); %>

